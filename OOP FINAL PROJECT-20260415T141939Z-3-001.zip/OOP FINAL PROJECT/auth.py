from flask import Blueprint, request, redirect, url_for, flash, session
import os

auth_bp = Blueprint('auth', __name__)

FILE_NAME = "users.txt"


# 🔹 Load users
def load_users():
    users = {}

    if not os.path.exists(FILE_NAME):
        return users

    with open(FILE_NAME, "r") as f:
        for line in f:
            line = line.strip()

            if not line or "|" not in line:
                continue  # skip bad lines

            parts = line.split("|")

            if len(parts) != 2:
                continue  # skip corrupted lines

            username, password = parts
            users[username] = password

    return users


# 🔹 Save user
def save_user(username, password):
    with open(FILE_NAME, "a") as f:
        f.write(f"{username}|{password}\n")


# 🔹 REGISTER
@auth_bp.route('/register', methods=['POST'])
def register():
    username = request.form['username']
    password = request.form['password']

    users = load_users()

    if username in users:
        flash('Username already registered.')
        return redirect(url_for('index'))

    save_user(username, password)

    flash('Registration successful! You can now log in.')
    return redirect(url_for('index'))


# 🔹 LOGIN
@auth_bp.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']

    users = load_users()

    if username in users and users[username] == password:
        session['userid'] = username
        session['username'] = username
        flash('Login successful!')
    else:
        flash('Invalid credentials.')

    return redirect(url_for('index'))


# 🔹 LOGOUT
@auth_bp.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully!')
    return redirect(url_for('index'))