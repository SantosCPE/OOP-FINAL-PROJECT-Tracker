from flask import Flask, render_template, request, url_for, flash, redirect, session
from flask_sqlalchemy import SQLAlchemy
from auth import auth_bp
from datetime import date, datetime, date as dt_date
from sqlalchemy import func

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///expenses.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'my-secret-key'

db = SQLAlchemy(app)

# MODEL
class Expense(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(100), nullable=False) # Add this line
    description = db.Column(db.String(360), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    category = db.Column(db.String(50), nullable=False)
    date = db.Column(db.Date, nullable=False, default=date.today)

with app.app_context():
    db.create_all()

CATEGS = ['Food', 'Transport', 'Rent', 'Utilities', 'Health']

# REGISTER AUTH
app.register_blueprint(auth_bp)

# DATE PARSER
def parse_date_or_none(s: str):
    if not s:
        return None
    try:
        return datetime.strptime(s, "%Y-%m-%d").date()
    except ValueError:
        return None


# MAIN DASHBOARD
@app.route("/")
def index():
    logged_in = 'userid' in session
    username = session.get('userid')

    if logged_in:
        q = Expense.query.filter_by(user_id=username)
    else:
        q = Expense.query.filter_by(user_id=None)

    start_str = (request.args.get("start") or "").strip()
    end_str = (request.args.get("end") or "").strip()
    select_categ = (request.args.get("category") or "").strip()

    start_date = parse_date_or_none(start_str)
    end_date = parse_date_or_none(end_str)

    if start_date and end_date and end_date < start_date:
        flash("End Date cannot be before Start Date", "error")
        start_date = end_date = None

    if start_date:
        q = q.filter(Expense.date >= start_date)
    if end_date:
        q = q.filter(Expense.date <= end_date)
    if select_categ:
        q = q.filter(Expense.category == select_categ)

    expenses = q.order_by(Expense.date.desc(), Expense.id.desc()).all()
    total = round(sum(e.amount for e in expenses), 2)

    # PIE CHART
    cat_q = db.session.query(Expense.category, func.sum(Expense.amount)).filter(Expense.user_id == username)
    if start_date:
        cat_q = cat_q.filter(Expense.date >= start_date)
    if end_date:
        cat_q = cat_q.filter(Expense.date <= end_date)
    if select_categ:
        cat_q = cat_q.filter(Expense.category == select_categ)

    cat_row = cat_q.group_by(Expense.category).all()
    cat_labels = [c for c, _ in cat_row]
    cat_values = [round(float(s or 0), 2) for _, s in cat_row]

    # DAILY CHART
    day_q = db.session.query(Expense.date, func.sum(Expense.amount)).filter(Expense.user_id == username)
    if start_date:
        day_q = day_q.filter(Expense.date >= start_date)
    if end_date:
        day_q = day_q.filter(Expense.date <= end_date)
    if select_categ:
        day_q = day_q.filter(Expense.category == select_categ)

    day_row = day_q.group_by(Expense.date).order_by(Expense.date.asc()).all()
    day_labels = [d.isoformat() for d, _ in day_row]
    day_values = [round(float(s or 0), 2) for _, s in day_row]

    return render_template(
        "index.html",
        expenses=expenses,
        categories=CATEGS,
        total=total,
        today=date.today().isoformat(),
        start_str=start_str,
        end_str=end_str,
        select_categ=select_categ,
        cat_labels=cat_labels,
        cat_values=cat_values,
        day_labels=day_labels,
        day_values=day_values,
        username=session.get('username'),
        loggedin=logged_in
    )

# ADD
@app.route("/add", methods=['POST'])
def add():
    description = request.form.get("description", "").strip()
    amount_ctg = request.form.get("amount", "").strip()
    category = request.form.get("category", "").strip()
    date_str = request.form.get("date", "").strip()

    user_id = session.get('userid')
    if not user_id:
        flash("You must be logged in", "error")
        return redirect(url_for("index"))

    if not description or not amount_ctg or not category:
        flash("Please fill all fields", "error")
        return redirect(url_for("index"))

    try:
        amount = float(amount_ctg)
        if amount <= 0:
            raise ValueError
    except ValueError:
        flash("Amount must be positive", "error")
        return redirect(url_for("index"))

    try:
        d = datetime.strptime(date_str, "%Y-%m-%d").date() if date_str else date.today()
    except ValueError:
        d = date.today()

    e = Expense(description=description, amount=amount, category=category, date=d, user_id=user_id)
    db.session.add(e)
    db.session.commit()

    flash("Expense added", "success")
    return redirect(url_for("index"))


# DELETE
@app.route('/delete/<int:expense_id>', methods=['POST'])
def delete(expense_id):
    e = Expense.query.get_or_404(expense_id)

    if e.user_id != session.get('userid'):
        flash("Unauthorized", "error")
        return redirect(url_for('index'))
    
    db.session.delete(e)
    db.session.commit()
    flash("Deleted", "success")
    return redirect(url_for("index"))


# EDIT
@app.route('/edit/<int:expense_id>', methods=['GET'])
def edit(expense_id):
    e = Expense.query.get_or_404(expense_id)

    if e.user_id != session.get('userid'):
        flash("Unauthorized", "error")
        return redirect(url_for('index'))
    
    return render_template("edit.html", expense=e, categories=CATEGS, today=dt_date.today().isoformat())


@app.route('/edit/<int:expense_id>', methods=['POST'])
def edit_post(expense_id):
    e = Expense.query.get_or_404(expense_id)

    if e.user_id != session.get('userid'):
        flash("Unauthorized", "error")
        return redirect(url_for('index'))

    description = request.form.get("description", "").strip()
    amount_str = request.form.get("amount", "").strip()
    category = request.form.get("category", "").strip()
    date_str = request.form.get("date", "").strip()

    if not description or not amount_str or not category:
        flash("Please fill all fields", "error")
        return redirect(url_for("edit", expense_id=expense_id))

    try:
        amount = float(amount_str)
        if amount <= 0:
            raise ValueError
    except ValueError:
        flash("Amount must be positive", "error")
        return redirect(url_for("edit", expense_id=expense_id))

    try:
        d = datetime.strptime(date_str, "%Y-%m-%d").date() if date_str else dt_date.today()
    except ValueError:
        d = dt_date.today()

    e.description = description
    e.amount = amount
    e.category = category
    e.date = d

    db.session.commit()
    flash("Updated", "success")
    return redirect(url_for("index"))


if __name__ == "__main__":
    app.run(debug=True, port=4848)